﻿BigBoxAutoPlay
==============
BigBoxAutoPlay is a plug-in for BigBox that can automatically launch into a game when BigBox starts up.  It includes a configuration utility that you can access inside LaunchBox to set up how the auto-play works.

`LaunchBox Forums <https://forums.launchbox-app.com/files/file/3267-big-box-auto-play>`
`Github Repo <https://github.com/AtomFry/BigBoxAutoPlay>`

Contents
========

.. toctree::
   :maxdepth: 2

   install
   configure